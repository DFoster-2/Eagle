def homeScreenStart():
  print("yes")
  from Apps.Encrypter.EncryptHomeScreen import encryptstart2
  encryptstart2()