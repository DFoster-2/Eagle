#from Apps.Encrypter.EncryptHomeScreen import *; encryptstart2()
from Software.Start import *
#from Apps.Translater.Translat import *
#from Software.Login.Encrpt import  encrypt; encrypt()
#from Software.Login.Decrypt import  decrypt; decrypt()
#from Software.Login.sineIn import SineIn; SineIn("hi","moo")
#from Apps.EncrypterFiles.main2 import *
#from Software.Login.SineUp import SineuP; SineuP("ghjdjk","hdfhdhdfdfhdh")
